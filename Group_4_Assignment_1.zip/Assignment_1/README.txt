To execute the code for assignment 1 the following step must be followed:
1) Open de Read_im.py file in the Code folder
2) Press run
3) Select a folder containing images using the prompt
